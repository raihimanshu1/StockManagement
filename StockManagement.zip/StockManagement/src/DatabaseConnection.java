
import java.sql.Connection;
import java.sql.DriverManager;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Lenovo
 */
public class DatabaseConnection {
    
    public static Connection getConnection(){
		Connection con=null;
		try{
                        String url="jdbc:mysql://localhost:3306/stockmanagement";
	                String un="root";
	                String pass="kali";
			Class.forName("com.mysql.jdbc.Driver");
			con=(Connection) DriverManager.getConnection(url,un,pass);
                        System.out.println(con.toString());
                        return con;
		}catch(Exception e){System.out.println(e);}
		return con;
}
}